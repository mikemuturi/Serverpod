abstract final class ExampleUtil {
  static String buildGreeting(String name) {
    return 'Hello $name';
  }
}
