package com.example.my_budget_expense_app_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
