//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import connectivity_plus

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  ConnectivityPlusPlugin.register(with: registry.registrar(forPlugin: "ConnectivityPlusPlugin"))
}
